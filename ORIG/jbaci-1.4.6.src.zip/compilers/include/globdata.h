/* BenAri Concurrent Pascal PCODE Compiler & Interpreter Global Variables */

#include "../include/bacicnty.h"    /* bring in constants & types */

extern char  comp_proot[];

extern   FNAME_STRING   pcode_fname;

extern   char           pcode_suffix[];
extern   char           pobject_suffix[];

extern   char           outerblock_name[];

extern   TYPENAME       typenames[];
extern   OBJNAME        objnames[];

extern   FNAME_STRING   filename_line;


/*
 *
 * $Id: globdata.h,v 1.7 2007/06/01 17:41:16 bynum Exp $
 *
 */
