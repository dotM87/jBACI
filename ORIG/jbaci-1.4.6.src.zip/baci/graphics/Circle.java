package baci.graphics;
import java.awt.*;
import java.awt.geom.*;
public class Circle extends GraphicsObject {
    Circle(TheGraphics parent, int handle, int c, int x, int y, int d, int dummy, int theFlags) {
        super(parent, handle, 1, c, x, y, d, d, theFlags);
    }
	public void Paint(Graphics2D g) {
        if (isVisible) {
			if ((flags & DRAW_FILL) == DRAW_FILL) g.fillOval(xPosition, yPosition, xSize, ySize);
			else                                  g.drawOval(xPosition, yPosition, xSize, ySize);
        }
    }

}
