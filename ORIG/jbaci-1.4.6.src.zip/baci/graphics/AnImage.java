package baci.graphics;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.*;


/**
 * This program has been modified by Moti Ben-Ari (December 2002).
 * The original was taken from the BlueJ examples.
 * There was not copyright on the original.
 *
 * A circle that can be manipulated and that draws itself on a canvas.
 *
  * @author  Michael Kolling and David J. Barnes
 * @version 1.0  (15 July 2000)
 */

public class AnImage extends GraphicsObject {

    /**
      Create a new circle of diameter d, at position x,y of color c.
    */
	private BufferedImage bi;
    AnImage(TheGraphics parent, int handle, int c, int x, int y, int width, int height, int theFlags)
    {
        super(parent, handle, 1, c, x, y, width, height, theFlags);		
    }

    /*
     * Draw the circle with current specifications on screen.
     */
	public void Paint(Graphics2D g) {
        if (isVisible && (bi!=null)) {
			g.drawImage(bi, xPosition, yPosition, null);
        }
    }

	public void handleProperty(String name, String value, boolean isPrivate) {
		if (isPrivate && name.equals("icon")) {
			try {
				bi = ImageIO.read(new File(value));
			} catch (Exception e) {
				System.out.println("Error reading " + value);
				return;
			}	
			System.out.println("Success in reading image=" + value);
		}
	}
}
