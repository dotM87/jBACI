   /* BenAri external declarations for include file code */

#include "../include/bacicnty.h"

extern InputFile *infile;

extern int curr_infile;

extern int last_infile;

extern int include_level;

extern int open_infile(FNAME_STRING fname, int curr_infile);

extern int close_infile(int curr_infile);

  
/*
 *
 *  $Id: incfiles.h,v 1.3 2007/06/01 17:41:16 bynum Exp $
 *
 */

