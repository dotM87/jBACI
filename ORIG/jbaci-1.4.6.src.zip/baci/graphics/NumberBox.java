package baci.graphics;

import java.awt.*;
import java.awt.geom.*;
import java.awt.image.*;
import javax.swing.*;
import javax.imageio.ImageIO;
import java.io.*;

public class NumberBox extends RoundRect {
	private BufferedImage bi;
	private Font          font;
	private int           fontSize;
	private int           valueToShow;
    NumberBox(TheGraphics parent, int handle, int c, int x, int y, int width, int height, int theFlags) {
        super(parent, handle, c, x, y, width, height, theFlags | GraphicsObject.DRAW_FILL);		
		fontSize = java.lang.Math.min(xSize, ySize)/2;
        font = new Font("Serif", Font.PLAIN, fontSize);
		valueToShow=0;
    }

    /*
		* Draw the circle with current specifications on screen.
         */
	public void Paint(Graphics2D g) {
		super.Paint(g);
        if (isVisible) {
			g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
			g.setFont(font);
			FontMetrics fm = g.getFontMetrics();
			Color saved_color = g.getColor();
			int rc=(~saved_color.getRed()&0xff);
			int gc=(~saved_color.getGreen()&0xff);
			int bc=(~saved_color.getBlue()&0xff);
			g.setColor(new Color(rc,gc,bc));
			String sValue = Integer.toString(valueToShow); /* is the value */
			
			int dx=(xSize-(fm.charWidth('0')*sValue.length()))/2;
			int dy = ySize/2+fm.getAscent()/2-fm.getLeading();
			g.drawString(sValue, xPosition+dx, yPosition+dy);		
			g.setColor(saved_color);
        }
    }
	/** When c is negative, it actually a change in value for showing */
	public void changeColor(int c) {
		if (c>=0) {
			super.changeColor(c);
		}
		else {
			valueToShow=-c;			
			parent.event(2);
		}		
	}
	public void changeSize(int newWidth, int newHeight) {
		super.changeSize(newWidth, newHeight);		
		fontSize = java.lang.Math.min(xSize, ySize)/2;
		font = new Font("Serif", Font.PLAIN, fontSize);
		
	}
	public void handleProperty(String name, String value, boolean isPrivate) {
	}
}
