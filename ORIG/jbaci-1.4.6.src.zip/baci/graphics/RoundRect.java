package baci.graphics;
import java.awt.*;
import java.awt.geom.*;

public class RoundRect extends GraphicsObject {
    RoundRect(TheGraphics parent, int handle, int c, int x, int y, int w, int h, int theFlags) {
        super(parent, handle, 3, c, x, y, w, h, theFlags);
    }
    public void Paint(Graphics2D g) {
        if (isVisible) {
			int r=Math.max(xSize,ySize)/5;
			if ((flags & DRAW_FILL) == DRAW_FILL) 
				g.fillRoundRect(xPosition, yPosition, xSize, ySize, r, r);
			Color saved_color = g.getColor();
			g.setColor(Color.BLACK);
			g.drawRoundRect(xPosition, yPosition, xSize, ySize, r, r);
			g.setColor(saved_color);
        }
    }

}
