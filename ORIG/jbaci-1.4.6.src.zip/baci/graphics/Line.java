package baci.graphics;
import java.awt.*;
import java.awt.geom.*;
class Line extends GraphicsObject {
    Line(TheGraphics parent, int handle, int c, int x, int y, int xe, int ye, int theFlags)  {
        super(parent, handle, 2, c, x, y, xe, ye, theFlags);
    }
    public void moveTo(int newX, int newY) {
        xSize     = (xSize-xPosition) + newX;
        ySize     = (ySize-yPosition) + newY;
        xPosition = newX;
        yPosition = newY;
    }
    public void moveBy(int deltaX, int deltaY) {
        xPosition = xPosition + deltaX;
        yPosition = yPosition + deltaY;
        xSize     = xSize     + deltaX;
        ySize     = ySize     + deltaY;
    }
	public void Paint(Graphics2D g) {
        if (isVisible) {
			g.drawLine(xPosition, yPosition, xPosition+xSize, yPosition+ySize);
        }
    }

}
