package baci.graphics;
import java.awt.*;

public class Triangle extends GraphicsObject {
    Triangle(TheGraphics parent, int handle, int c, int x, int y, int w, int h, int theFlags) {
        super(parent, handle, 4, c, x, y, w, h, theFlags);
    }
	public void Paint(Graphics2D g) {
        if (isVisible) {
            int[] xpoints = { xPosition, xPosition + (xSize/2), xPosition - (xSize/2) };
            int[] ypoints = { yPosition, yPosition + ySize, yPosition + ySize };
			if ((flags & DRAW_FILL) == DRAW_FILL) g.fillPolygon(xpoints, ypoints, 3);
			else                                  g.drawPolygon(xpoints, ypoints, 3);
        }
    }

}
