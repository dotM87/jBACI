package baci.graphics;
import java.awt.*;
import java.awt.geom.*;
import javax.swing.*;

public class Rectangle extends GraphicsObject {
    Rectangle(TheGraphics parent, int handle, int c, int x, int y, int w, int h, int theFlags) {
        super(parent, handle, 3, c, x, y, w, h, theFlags);
    }
    public void Paint(Graphics2D g) {
        if (isVisible) {
			float alpha = 0.5f;
			Composite originalComposite = g.getComposite();
			g.setComposite(makeComposite(alpha));
			if ((flags & DRAW_FILL) == DRAW_FILL) g.fillRect(xPosition, yPosition, xSize, ySize);
			else                   				  g.drawRect(xPosition, yPosition, xSize, ySize);
			g.setComposite(originalComposite);
        }
    }

}
