package baci.graphics;
import baci.program.*;
import java.util.*;
import javax.swing.*;
import java.awt.*;
import baci.gui.Config;
import java.awt.image.BufferStrategy;
import java.awt.image.*;
import java.awt.Color;

/**
 * Store graphics objects and execute graphics commands
 *
 * @author Moti Ben-Ari
 * @version 20 December 2002
 * See copyright.txt.
 */
public class TheGraphics extends JFrame {
    private TreeMap 			elements;
    private Graphics2D 			graphic;
    private Color 				backgroundColour;
    private static TheGraphics 	mySingleton;
	private BufferStrategy 		bufferStrategy;
	private Program             program;
	
	private TheGraphics(int xPos, int yPos, int width, int height, Color bgColour) {
		elements = new TreeMap();
        this.setTitle("TheGraphics");
        this.getContentPane().setPreferredSize(new Dimension(width, height));
        this.setLocation(xPos, yPos);
        backgroundColour = bgColour;
        this.pack();
		createDoubleBuffer();
	}

	public void setProgram(Program theProgram) {
		program = theProgram;
	}
	
	public Program getProgram() {
		return program;
	}
	
    public void setVisible(boolean visible) {
    }

    public static TheGraphics instance()
    {
        if (mySingleton == null) {
            mySingleton = new TheGraphics(
			Config.getIntegerProperty("G_XPOS"), 
			Config.getIntegerProperty("G_YPOS"), 
			Config.getIntegerProperty("G_WIDTH"), 
			Config.getIntegerProperty("G_HEIGHT"),  
			Config.G_COLOR);
        }
        mySingleton.setVisible(true);
        return mySingleton;
    }
	
	// Create and add a graphics object to the list.
	// Parameter f gives the type of object to create.
	public void create(int h, int f, int c, int xp, int yp, int xs, int ys) {		
	    switch (f) {
		    case 1: elements.put(new Integer(h), new Circle   (this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_FILL)); break;
	        case 2: elements.put(new Integer(h), new Line     (this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_FILL)); break;
	        case 3: elements.put(new Integer(h), new Rectangle(this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_FILL)); break;
	        case 4: elements.put(new Integer(h), new Triangle (this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_FILL)); break;
			case 5: elements.put(new Integer(h), new AnImage  (this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_FILL)); break;
			case 6: elements.put(new Integer(h), new RoundRect(this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_FILL)); break;

		    case 21: elements.put(new Integer(h), new Circle   (this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_LINE)); break;
	        case 22: elements.put(new Integer(h), new Rectangle(this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_LINE)); break;
	        case 23: elements.put(new Integer(h), new Triangle (this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_LINE)); break;
			case 24: elements.put(new Integer(h), new RoundRect(this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_LINE)); break;	
			
			case 25: elements.put(new Integer(h), new NumberBox(this, h, c, xp, yp, xs, ys, GraphicsObject.DRAW_LINE)); break;	
		}
	}
	public void clear() {
		elements.clear();
	}

	public void event(int evtype) {
		repaint();
	}
	
	public GraphicsObject getGraphicsObject(int handle) {
		return (GraphicsObject) elements.get(new Integer(handle));
	}
	
	private void createDoubleBuffer() {
		try {
			this.createBufferStrategy(2);
		} catch (IllegalArgumentException e) {
			System.err.println("Exception:"+"requested number of Buffers is illegal - falling back to default");
		}
		try {
			Thread.sleep(200);
		} catch (InterruptedException e) {
			Thread.currentThread().interrupt();
		}		
		bufferStrategy = this.getBufferStrategy();
		graphic = (Graphics2D)bufferStrategy.getDrawGraphics();
	}

	public void paint(Graphics g) {	
		graphic.setColor(this.getBackground());
		graphic.fillRect(0, 0, this.getWidth(), this.getHeight());
		Collection c = elements.values();
		Iterator itr = c.iterator();
		while (itr.hasNext()) {
			GraphicsObject go = (GraphicsObject)(itr.next());
			graphic.setColor(go.color);
			go.Paint(graphic);
		}
		graphic.dispose();		
		if (bufferStrategy.contentsLost())
			createDoubleBuffer();			
		bufferStrategy.show(); 
		try { Thread.sleep(20); } catch (Exception e) {}		
		graphic = (Graphics2D)bufferStrategy.getDrawGraphics();		
    }
}
